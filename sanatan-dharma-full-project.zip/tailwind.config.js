/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Divine color theme
        gold: {
          light: '#FFD700',
          DEFAULT: '#D4AF37',
          dark: '#996515',
        },
        saffron: {
          light: '#FF9933',
          DEFAULT: '#FF7722',
          dark: '#FF5500',
        },
        deepBlue: {
          light: '#0F2E68',
          DEFAULT: '#0A1F47',
          dark: '#061232',
        },
        divine: {
          1: '#FFC226', // Golden yellow
          2: '#FF5722', // Deep orange/saffron
          3: '#9C27B0', // Purple
          4: '#1A237E', // Indigo
          5: '#01579B', // Deep blue
        },
      },
      fontFamily: {
        sanskrit: ['var(--font-sanskrit)', 'serif'],
        body: ['var(--font-body)', 'sans-serif'],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-cosmic': 'linear-gradient(to right, #0F2E68, #1A237E, #9C27B0)',
        'temple-pattern': "url('/images/temple-pattern.png')",
      },
      animation: {
        'cosmic-float': 'float 6s ease-in-out infinite',
        'divine-pulse': 'pulse 3s ease-in-out infinite',
        'om-spin': 'spin 10s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
  safelist: [
    'font-sanskrit',
    'font-body'
  ],
  plugins: [],
} 