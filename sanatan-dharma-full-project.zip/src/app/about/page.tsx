'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Image from 'next/image';
import { FaOm } from 'react-icons/fa';

// Animation variants for section fade-in
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.8, ease: "easeOut" }
  }
};

export default function AboutPage() {
  // For scroll-triggered animations
  const [ref1, inView1] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });
  
  const [ref2, inView2] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });
  
  const [ref3, inView3] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });
  
  const [ref4, inView4] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  return (
    <div className="min-h-screen cosmic-bg py-20 px-4">
      {/* Page Title */}
      <div className="max-w-7xl mx-auto text-center mb-20">
        <motion.h1 
          className="text-4xl md:text-5xl lg:text-6xl font-sanskrit text-gold-DEFAULT mb-6 divine-glow"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          About Sanatan Dharma
        </motion.h1>
        <motion.div 
          className="h-1 w-40 bg-gradient-cosmic mx-auto rounded-full"
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 160, opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
        ></motion.div>
      </div>
      
      {/* Introduction Section */}
      <motion.section 
        ref={ref1}
        initial="hidden"
        animate={inView1 ? "visible" : "hidden"}
        variants={fadeIn}
        className="max-w-5xl mx-auto mb-24"
      >
        <div className="flex flex-col md:flex-row gap-12 items-center">
          <div className="md:w-1/2">
            <h2 className="text-3xl font-sanskrit text-saffron-light mb-6">What is Sanatan Dharma?</h2>
            <p className="text-lg text-gray-300 mb-4">
              Sanatan Dharma, often referred to as Hinduism, is the world's oldest living religion. The term "Sanatan" means eternal, 
              and "Dharma" refers to the righteous duty, divine law, or the way of life.
            </p>
            <p className="text-lg text-gray-300 mb-4">
              Unlike many other religions, Sanatan Dharma does not have a single founder, a single holy book, or a single set of teachings. 
              It is a way of life that encompasses a wide range of philosophies, beliefs, and practices.
            </p>
            <p className="text-lg text-gray-300">
              The core essence of Sanatan Dharma lies in understanding that there are many paths to reach the divine, 
              and each individual may choose the path that resonates most with them.
            </p>
          </div>
          <div className="md:w-1/2 relative">
            <div className="aspect-video rounded-lg overflow-hidden divine-border">
              <div className="relative w-full h-full">
                <div className="absolute inset-0 flex items-center justify-center bg-deepBlue-DEFAULT">
                  <FaOm className="text-6xl text-gold-light" />
                </div>
              </div>
            </div>
            <div className="absolute -bottom-4 -right-4 bg-deepBlue-DEFAULT p-4 rounded-lg divine-border">
              <p className="text-gold-light font-sanskrit text-lg">"ॐ"</p>
              <p className="text-sm text-gray-300">The Primordial Sound</p>
            </div>
          </div>
        </div>
      </motion.section>
      
      {/* Core Beliefs Section */}
      <motion.section 
        ref={ref2}
        initial="hidden"
        animate={inView2 ? "visible" : "hidden"}
        variants={fadeIn}
        className="max-w-5xl mx-auto mb-24 px-4"
      >
        <h2 className="text-3xl font-sanskrit text-saffron-light mb-8 text-center">Core Beliefs</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Brahman</h3>
            <p className="text-gray-300">
              The belief in one supreme reality (Brahman) that is beyond human comprehension, 
              yet manifests in various forms that we can connect with.
            </p>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Karma</h3>
            <p className="text-gray-300">
              The law of cause and effect. Every action has consequences that may manifest 
              in this life or future ones, shaping our journey.
            </p>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Dharma</h3>
            <p className="text-gray-300">
              The righteous duty that each person must follow according to their stage in life 
              and position in society to maintain cosmic order.
            </p>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Moksha</h3>
            <p className="text-gray-300">
              Liberation from the cycle of birth and death, which is the ultimate goal 
              of spiritual practice in Sanatan Dharma.
            </p>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Samsara</h3>
            <p className="text-gray-300">
              The continuous cycle of birth, death, and rebirth that souls undergo 
              until they achieve Moksha or liberation.
            </p>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Yoga</h3>
            <p className="text-gray-300">
              The various spiritual practices and disciplines that help one achieve 
              union with the divine and self-realization.
            </p>
          </div>
        </div>
      </motion.section>
      
      {/* Why Sanatan Dharma is Eternal & Scientific */}
      <motion.section 
        ref={ref3}
        initial="hidden"
        animate={inView3 ? "visible" : "hidden"}
        variants={fadeIn}
        className="max-w-5xl mx-auto mb-24"
      >
        <div className="flex flex-col md:flex-row-reverse gap-12 items-center">
          <div className="md:w-1/2">
            <h2 className="text-3xl font-sanskrit text-saffron-light mb-6">Eternal & Scientific Wisdom</h2>
            <p className="text-lg text-gray-300 mb-4">
              Sanatan Dharma is not just a spiritual tradition but also a repository of scientific knowledge. 
              Ancient Hindu texts like the Vedas contain insights about astronomy, mathematics, medicine, and physics 
              that were discovered by modern science thousands of years later.
            </p>
            <p className="text-lg text-gray-300 mb-4">
              Practices like Yoga and meditation, which have been part of Sanatan tradition for millennia, 
              are now scientifically proven to benefit physical and mental health.
            </p>
            <p className="text-lg text-gray-300">
              The concept of interconnectedness of all beings and the cyclical nature of the universe 
              aligns closely with modern ecological understanding and quantum physics.
            </p>
          </div>
          <div className="md:w-1/2 relative">
            <div className="aspect-video rounded-lg overflow-hidden divine-border">
              <div className="relative w-full h-full">
                <div className="absolute inset-0 flex items-center justify-center bg-deepBlue-DEFAULT">
                  <FaOm className="text-6xl text-gold-light" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.section>
      
      {/* Relevance in Modern Life */}
      <motion.section 
        ref={ref4}
        initial="hidden"
        animate={inView4 ? "visible" : "hidden"}
        variants={fadeIn}
        className="max-w-5xl mx-auto mb-12"
      >
        <h2 className="text-3xl font-sanskrit text-saffron-light mb-8 text-center">Relevance in Modern Life</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-gradient-to-br from-deepBlue-DEFAULT/40 to-deepBlue-dark/40 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Stress Management</h3>
            <p className="text-gray-300">
              Ancient practices like meditation, pranayama (breath control), and yoga provide effective tools 
              for managing the stress and anxiety of modern life.
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-deepBlue-DEFAULT/40 to-deepBlue-dark/40 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Environmental Harmony</h3>
            <p className="text-gray-300">
              The reverence for nature and understanding of the interconnectedness of all beings 
              provides a framework for sustainable living in an increasingly polluted world.
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-deepBlue-DEFAULT/40 to-deepBlue-dark/40 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Ethical Guidance</h3>
            <p className="text-gray-300">
              Principles like non-violence (Ahimsa), truthfulness (Satya), and non-stealing (Asteya) 
              provide a moral compass for navigating complex ethical dilemmas.
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-deepBlue-DEFAULT/40 to-deepBlue-dark/40 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Holistic Well-being</h3>
            <p className="text-gray-300">
              Ayurveda, the ancient system of medicine, offers holistic approaches to health that address 
              the root causes of illness rather than just treating symptoms.
            </p>
          </div>
        </div>
      </motion.section>
      
      {/* Quote */}
      <div className="max-w-5xl mx-auto text-center px-4 mb-12">
        <blockquote className="text-2xl text-gold-light font-sanskrit italic">
          "Truth is one, the wise call it by many names."
          <footer className="text-base text-gray-400 mt-2">— Rig Veda</footer>
        </blockquote>
      </div>
    </div>
  );
} 