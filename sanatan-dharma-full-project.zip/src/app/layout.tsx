import type { Metadata } from "next";
import { Yatra_One, Poppins } from "next/font/google";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import "./globals.css";

// Define fonts
const sanskritFont = Yatra_One({
  weight: ["400"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-sanskrit",
});

const bodyFont = Poppins({
  weight: ["300", "400", "500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-body",
});

export const metadata: Metadata = {
  title: "Sanatan Dharma - Hindu New Year Awareness",
  description: "Discover the eternal truth of Sanatan Dharma and celebrate the authentic Hindu New Year",
  keywords: "Sanatan Dharma, Hindu New Year, Vikram Samvat, Hinduism, Hindu traditions, Hindu culture, Hindu values",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${sanskritFont.variable} ${bodyFont.variable}`}>
      <body>
        <Navbar />
        <main className="pt-16">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
