'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { FaCalendarAlt, FaHistory, FaQuestion, FaStar, FaOm } from 'react-icons/fa';

// Animation variants for section fade-in
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.8, ease: "easeOut" }
  }
};

export default function NewYearPage() {
  const [vikramYear, setVikramYear] = useState(2081); // Current Vikram Samvat year (2024-25)
  
  // Calculate current Vikram Samvat year
  useEffect(() => {
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth(); // 0-indexed (0 = January)
    
    // Vikram Samvat is roughly 56.7 years ahead of Gregorian calendar
    // Hindu New Year typically falls in March-April (Chaitra)
    // If we're before Hindu New Year (assuming April), subtract 1 from the offset
    const offset = currentMonth < 3 ? 56 : 57;
    setVikramYear(currentYear + offset);
  }, []);
  
  // For scroll-triggered animations
  const [ref1, inView1] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });
  
  const [ref2, inView2] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });
  
  const [ref3, inView3] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });
  
  const [ref4, inView4] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  return (
    <div className="min-h-screen cosmic-bg py-20 px-4">
      {/* Page Title */}
      <div className="max-w-7xl mx-auto text-center mb-20">
        <motion.h1 
          className="text-4xl md:text-5xl lg:text-6xl font-sanskrit text-gold-DEFAULT mb-6 divine-glow"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Hindu New Year: The Forgotten Truth
        </motion.h1>
        <motion.div 
          className="h-1 w-40 bg-gradient-cosmic mx-auto rounded-full"
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 160, opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
        ></motion.div>
      </div>
      
      {/* What is Vikram Samvat Section */}
      <motion.section 
        ref={ref1}
        initial="hidden"
        animate={inView1 ? "visible" : "hidden"}
        variants={fadeIn}
        className="max-w-5xl mx-auto mb-24"
      >
        <div className="flex flex-col md:flex-row gap-12 items-center">
          <div className="md:w-1/2">
            <div className="flex items-center mb-6">
              <FaCalendarAlt className="text-saffron-light text-2xl mr-3" />
              <h2 className="text-3xl font-sanskrit text-saffron-light">What is Vikram Samvat?</h2>
            </div>
            <p className="text-lg text-gray-300 mb-4">
              Vikram Samvat is the historical Hindu calendar used in the Indian subcontinent. Named after King Vikramaditya, 
              it began in 57 BCE when he defeated the Saka invaders.
            </p>
            <p className="text-lg text-gray-300 mb-4">
              Unlike the Gregorian calendar that starts on January 1, the Hindu New Year based on Vikram Samvat begins with the 
              month of Chaitra (March-April) when spring begins in India.
            </p>
            <p className="text-lg text-gray-300 mb-4">
              The current Vikram Samvat year is <span className="text-gold-light font-sanskrit">{vikramYear}</span>, which is approximately 
              57 years ahead of the Gregorian calendar.
            </p>
            <p className="text-lg text-gray-300">
              This calendar is not just a way to measure time but is deeply integrated with Hindu festivals, 
              rituals, and astronomical observations.
            </p>
          </div>
          <div className="md:w-1/2 relative">
            <div className="aspect-video rounded-lg overflow-hidden divine-border">
              <div className="absolute inset-0 flex items-center justify-center bg-deepBlue-DEFAULT">
                <div className="text-center">
                  <FaCalendarAlt className="text-6xl text-gold-light mx-auto mb-4" />
                  <p className="text-gold-light font-sanskrit text-xl">Vikram Samvat</p>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-4 -right-4 bg-deepBlue-DEFAULT p-4 rounded-lg divine-border">
              <p className="text-gold-light font-sanskrit text-lg">"विक्रम संवत"</p>
              <p className="text-sm text-gray-300">The Era of Vikramaditya</p>
            </div>
          </div>
        </div>
      </motion.section>
      
      {/* Why it's the real Hindu New Year */}
      <motion.section 
        ref={ref2}
        initial="hidden"
        animate={inView2 ? "visible" : "hidden"}
        variants={fadeIn}
        className="max-w-5xl mx-auto mb-24"
      >
        <div className="flex flex-col md:flex-row-reverse gap-12 items-center">
          <div className="md:w-1/2">
            <div className="flex items-center mb-6">
              <FaQuestion className="text-saffron-light text-2xl mr-3" />
              <h2 className="text-3xl font-sanskrit text-saffron-light">Why is it the True Hindu New Year?</h2>
            </div>
            <p className="text-lg text-gray-300 mb-4">
              The Hindu New Year begins with the month of Chaitra, marking the spring equinox and the beginning of a new harvest season. 
              This natural transition makes it the most logical time to mark a new year.
            </p>
            <p className="text-lg text-gray-300 mb-4">
              Unlike January 1, which has no particular significance in Hindu cosmology, the Hindu New Year is tied to 
              celestial movements and agricultural cycles that have been observed for thousands of years.
            </p>
            <p className="text-lg text-gray-300">
              The New Year is celebrated as <span className="text-gold-light">Gudi Padwa</span> in Maharashtra, 
              <span className="text-gold-light"> Ugadi</span> in Andhra Pradesh and Karnataka, and by various other names across India, 
              showing its pan-Indian significance.
            </p>
          </div>
          <div className="md:w-1/2">
            <div className="bg-deepBlue-DEFAULT/20 backdrop-blur-sm p-6 rounded-lg divine-border">
              <h3 className="text-xl font-sanskrit text-gold-light mb-4 text-center">Benefits of Following Hindu Calendar</h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="text-gold-DEFAULT mr-2">✦</span>
                  <span className="text-gray-300">Aligns human life with natural cosmic cycles</span>
                </li>
                <li className="flex items-start">
                  <span className="text-gold-DEFAULT mr-2">✦</span>
                  <span className="text-gray-300">Preserves cultural and spiritual heritage</span>
                </li>
                <li className="flex items-start">
                  <span className="text-gold-DEFAULT mr-2">✦</span>
                  <span className="text-gray-300">Provides astrologically auspicious timing for activities</span>
                </li>
                <li className="flex items-start">
                  <span className="text-gold-DEFAULT mr-2">✦</span>
                  <span className="text-gray-300">Connects us with our ancestors and traditions</span>
                </li>
                <li className="flex items-start">
                  <span className="text-gold-DEFAULT mr-2">✦</span>
                  <span className="text-gray-300">More accurate for predicting seasonal changes in the Indian subcontinent</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </motion.section>
      
      {/* How did people forget */}
      <motion.section 
        ref={ref3}
        initial="hidden"
        animate={inView3 ? "visible" : "hidden"}
        variants={fadeIn}
        className="max-w-5xl mx-auto mb-24"
      >
        <div className="flex items-center justify-center mb-6">
          <FaHistory className="text-saffron-light text-2xl mr-3" />
          <h2 className="text-3xl font-sanskrit text-saffron-light text-center">How Did We Forget Our Calendar?</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Colonial Influence</h3>
            <p className="text-gray-300">
              During British colonial rule in India, the Gregorian calendar was imposed for administrative purposes, 
              gradually pushing the traditional Hindu calendar out of official use.
            </p>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Modernization & Globalization</h3>
            <p className="text-gray-300">
              As India modernized and became part of the global economy, the international Gregorian calendar 
              became more prominent in everyday life and business.
            </p>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Educational System</h3>
            <p className="text-gray-300">
              Modern education systems rarely teach traditional knowledge systems, including the Hindu calendar, 
              leading to a generational gap in understanding.
            </p>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Media & Popular Culture</h3>
            <p className="text-gray-300">
              Mainstream media and pop culture predominantly follow the Gregorian calendar, reinforcing January 1 
              as the universal New Year in public consciousness.
            </p>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-deepBlue-light/20 to-saffron-DEFAULT/10 p-6 rounded-lg divine-border">
          <p className="text-xl text-center text-gray-200">
            Despite these challenges, the Hindu calendar continues to be used for religious festivals, 
            astrological calculations, and cultural observances throughout India and by the Hindu diaspora worldwide.
          </p>
        </div>
      </motion.section>
      
      {/* How to celebrate properly */}
      <motion.section 
        ref={ref4}
        initial="hidden"
        animate={inView4 ? "visible" : "hidden"}
        variants={fadeIn}
        className="max-w-5xl mx-auto mb-12"
      >
        <div className="flex items-center justify-center mb-12">
          <FaStar className="text-saffron-light text-2xl mr-3" />
          <h2 className="text-3xl font-sanskrit text-saffron-light text-center">Celebrating Hindu New Year Today</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="relative">
            <div className="aspect-square rounded-lg overflow-hidden divine-border mb-4">
              <div className="absolute inset-0 flex items-center justify-center bg-deepBlue-DEFAULT">
                <div className="text-center">
                  <FaOm className="text-5xl text-gold-light mx-auto mb-2" />
                  <p className="text-gold-light">Rangoli</p>
                </div>
              </div>
            </div>
            <h3 className="text-xl font-sanskrit text-gold-light mb-2">Decorate Your Home</h3>
            <p className="text-gray-300">
              Create colorful rangoli at your doorstep, hang torans (door hangings), and decorate with flowers and mango leaves.
            </p>
          </div>
          
          <div className="relative">
            <div className="aspect-square rounded-lg overflow-hidden divine-border mb-4">
              <div className="absolute inset-0 flex items-center justify-center bg-deepBlue-DEFAULT">
                <div className="text-center">
                  <FaOm className="text-5xl text-gold-light mx-auto mb-2" />
                  <p className="text-gold-light">Puja</p>
                </div>
              </div>
            </div>
            <h3 className="text-xl font-sanskrit text-gold-light mb-2">Perform Puja</h3>
            <p className="text-gray-300">
              Conduct a special puja to Lord Brahma, Vishnu, and other deities, offering fresh fruits, flowers, and sweets.
            </p>
          </div>
          
          <div className="relative">
            <div className="aspect-square rounded-lg overflow-hidden divine-border mb-4">
              <div className="absolute inset-0 flex items-center justify-center bg-deepBlue-DEFAULT">
                <div className="text-center">
                  <FaOm className="text-5xl text-gold-light mx-auto mb-2" />
                  <p className="text-gold-light">Feast</p>
                </div>
              </div>
            </div>
            <h3 className="text-xl font-sanskrit text-gold-light mb-2">Prepare Special Food</h3>
            <p className="text-gray-300">
              Cook traditional dishes that include all six tastes: sweet, sour, salty, pungent, bitter, and astringent.
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Community Celebration</h3>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start">
                <span className="text-gold-DEFAULT mr-2">•</span>
                <span>Organize or attend community gatherings to celebrate together</span>
              </li>
              <li className="flex items-start">
                <span className="text-gold-DEFAULT mr-2">•</span>
                <span>Share the knowledge about Hindu New Year with friends and family</span>
              </li>
              <li className="flex items-start">
                <span className="text-gold-DEFAULT mr-2">•</span>
                <span>Participate in cultural programs that showcase traditional music and dance</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-deepBlue-DEFAULT/30 backdrop-blur-sm p-6 rounded-lg divine-border">
            <h3 className="text-xl font-sanskrit text-gold-light mb-4">Modern Adaptations</h3>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start">
                <span className="text-gold-DEFAULT mr-2">•</span>
                <span>Use Hindu calendar apps to track festivals and auspicious days</span>
              </li>
              <li className="flex items-start">
                <span className="text-gold-DEFAULT mr-2">•</span>
                <span>Share New Year greetings on social media with educational content</span>
              </li>
              <li className="flex items-start">
                <span className="text-gold-DEFAULT mr-2">•</span>
                <span>Start new positive habits or resolutions aligned with Dharmic principles</span>
              </li>
            </ul>
          </div>
        </div>
      </motion.section>
      
      {/* Quote */}
      <div className="max-w-5xl mx-auto text-center px-4 mb-12">
        <blockquote className="text-2xl text-gold-light font-sanskrit italic">
          "To forget one's ancestors is to be a brook without a source, a tree without roots."
          <footer className="text-base text-gray-400 mt-2">— Ancient Hindu Proverb</footer>
        </blockquote>
      </div>
    </div>
  );
} 