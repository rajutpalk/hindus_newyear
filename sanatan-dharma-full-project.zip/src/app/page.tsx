'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { FaOm } from 'react-icons/fa';
import Image from 'next/image';

export default function Home() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  // Calculate time until next Hindu New Year (example: April 10, 2024)
  // This would need to be calculated properly based on the Hindu calendar
  useEffect(() => {
    const targetDate = new Date('2025-04-10T00:00:00');
    
    const calculateTimeLeft = () => {
      const difference = targetDate.getTime() - new Date().getTime();
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        });
      }
    };
    
    const timer = setInterval(calculateTimeLeft, 1000);
    calculateTimeLeft();
    
    return () => clearInterval(timer);
  }, []);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.3,
        delayChildren: 0.6,
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { 
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <div className="min-h-screen cosmic-bg">
      {/* Hero Section */}
      <section className="relative h-screen flex flex-col items-center justify-center overflow-hidden px-4">
        {/* Background animation elements */}
        <div className="absolute inset-0 z-0">
          <motion.div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-9xl text-gold-light opacity-10"
            animate={{ 
              rotate: 360,
              scale: [1, 1.2, 1],
            }}
            transition={{ 
              rotate: { duration: 30, repeat: Infinity, ease: "linear" },
              scale: { duration: 8, repeat: Infinity, ease: "easeInOut" }
            }}
          >
            <FaOm />
          </motion.div>
          
          {/* Animated light beams */}
          {[...Array(5)].map((_, i) => (
            <motion.div 
              key={i}
              className="absolute top-1/2 left-1/2 h-[200vh] w-[50px] bg-gradient-to-t from-transparent via-gold-light to-transparent opacity-5"
              style={{ 
                originX: '50%',
                originY: '100%', 
                rotate: i * 72
              }}
              animate={{ 
                opacity: [0.03, 0.08, 0.03],
                scale: [0.8, 1, 0.8]
              }}
              transition={{ 
                duration: 8 + i, 
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.7
              }}
            />
          ))}
        </div>
        
        {/* Main content */}
        <motion.div 
          className="relative z-10 text-center max-w-4xl"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Grand Welcome Animation with Bhagwan's image */}
          <motion.div 
            className="mb-8 flex justify-center"
            variants={itemVariants}
          >
            <div className="relative w-48 h-48 sm:w-64 sm:h-64 rounded-full overflow-hidden border-4 border-gold-light divine-border">
              {/* Fallback for Shiva image */}
              <div className="absolute inset-0 flex items-center justify-center bg-deepBlue-DEFAULT">
                <FaOm className="text-6xl text-gold-light" />
              </div>
            </div>
          </motion.div>
          
          {/* Hindu New Year greeting */}
          <motion.h1 
            className="text-4xl md:text-6xl font-sanskrit text-gold-DEFAULT mb-4 divine-glow"
            variants={itemVariants}
          >
            Happy Hindu New Year
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-saffron-light mb-8"
            variants={itemVariants}
          >
            Vikram Samvat 2081
          </motion.p>
          
          {/* Powerful message */}
          <motion.p 
            className="text-xl md:text-2xl mb-12 text-white"
            variants={itemVariants}
          >
            "We are Hindus, and Hinduism is alive within us."
          </motion.p>
          
          {/* Countdown to next Hindu New Year */}
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
            variants={itemVariants}
          >
            <div className="bg-deepBlue-DEFAULT/50 backdrop-blur-sm p-4 rounded-lg border border-deepBlue-light">
              <div className="text-4xl font-sanskrit text-gold-light">{timeLeft.days}</div>
              <div className="text-gray-300">Days</div>
            </div>
            <div className="bg-deepBlue-DEFAULT/50 backdrop-blur-sm p-4 rounded-lg border border-deepBlue-light">
              <div className="text-4xl font-sanskrit text-gold-light">{timeLeft.hours}</div>
              <div className="text-gray-300">Hours</div>
            </div>
            <div className="bg-deepBlue-DEFAULT/50 backdrop-blur-sm p-4 rounded-lg border border-deepBlue-light">
              <div className="text-4xl font-sanskrit text-gold-light">{timeLeft.minutes}</div>
              <div className="text-gray-300">Minutes</div>
            </div>
            <div className="bg-deepBlue-DEFAULT/50 backdrop-blur-sm p-4 rounded-lg border border-deepBlue-light">
              <div className="text-4xl font-sanskrit text-gold-light">{timeLeft.seconds}</div>
              <div className="text-gray-300">Seconds</div>
            </div>
          </motion.div>
          
          {/* CTA buttons */}
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            variants={itemVariants}
          >
            <Link 
              href="/about" 
              className="px-8 py-3 bg-gold-DEFAULT hover:bg-gold-dark text-black font-medium rounded-full transition-colors"
            >
              Discover Sanatan
            </Link>
            <Link 
              href="/new-year" 
              className="px-8 py-3 border-2 border-saffron-light hover:bg-saffron-DEFAULT/10 text-white font-medium rounded-full transition-colors"
            >
              Learn About Hindu New Year
            </Link>
          </motion.div>
        </motion.div>
        
        {/* Scroll indicator */}
        <motion.div 
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="text-gold-light/50">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </motion.div>
      </section>

      {/* Brief Introduction Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-black to-deepBlue-dark">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-sanskrit text-gold-DEFAULT mb-6">The Eternal Truth</h2>
              <p className="text-lg text-gray-300 mb-4">
                Sanatan Dharma is not just a religion but a way of life that has guided humanity for thousands of years. 
                Its principles are timeless and remain relevant even in today's modern world.
              </p>
              <p className="text-lg text-gray-300 mb-8">
                Join us on this spiritual journey to rediscover our roots and understand the profound wisdom 
                that has been passed down through generations.
              </p>
              <Link 
                href="/about" 
                className="text-gold-light hover:text-gold-DEFAULT flex items-center transition-colors"
              >
                Learn more 
                <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-lg overflow-hidden divine-border">
                {/* Fallback for temple image */}
                <div className="absolute inset-0 flex items-center justify-center bg-deepBlue-DEFAULT">
                  <FaOm className="text-6xl text-gold-light" />
                </div>
              </div>
              <div className="absolute -bottom-4 -left-4 bg-deepBlue-DEFAULT p-4 rounded-lg divine-border">
                <p className="text-gold-light font-sanskrit text-lg">"सत्यमेव जयते"</p>
                <p className="text-sm text-gray-300">Truth Alone Triumphs</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
