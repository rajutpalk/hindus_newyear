'use client';

import Link from 'next/link';
import { FaOm, FaFacebook, FaTwitter, FaInstagram, FaYoutube } from 'react-icons/fa';
import { motion } from 'framer-motion';
import TemplatePattern from '../ui/TemplatePattern';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-deepBlue-dark relative overflow-hidden">
      {/* Divine Pattern Background */}
      <TemplatePattern opacity={0.05} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Logo and About */}
          <div>
            <Link href="/" className="flex items-center">
              <motion.div 
                className="text-gold-light text-3xl mr-2"
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              >
                <FaOm />
              </motion.div>
              <span className="font-sanskrit text-2xl text-gold-DEFAULT divine-glow">Sanatan</span>
            </Link>
            <p className="mt-4 text-gray-300">Spreading awareness about Hindu New Year and Sanatan Dharma's timeless wisdom.</p>
            <div className="mt-6 flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-gold-light transition-colors">
                <FaFacebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold-light transition-colors">
                <FaTwitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold-light transition-colors">
                <FaInstagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold-light transition-colors">
                <FaYoutube className="h-6 w-6" />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-sanskrit text-saffron-light mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-300 hover:text-gold-light transition-colors">About Sanatan Dharma</Link></li>
              <li><Link href="/new-year" className="text-gray-300 hover:text-gold-light transition-colors">Hindu New Year</Link></li>
              <li><Link href="/gallery" className="text-gray-300 hover:text-gold-light transition-colors">Divine Gallery</Link></li>
              <li><Link href="/teachings" className="text-gray-300 hover:text-gold-light transition-colors">Teachings</Link></li>
              <li><Link href="/modern-world" className="text-gray-300 hover:text-gold-light transition-colors">Hinduism Today</Link></li>
              <li><Link href="/interactive" className="text-gray-300 hover:text-gold-light transition-colors">Know Your Dharma</Link></li>
            </ul>
          </div>
          
          {/* Subscribe */}
          <div>
            <h3 className="text-xl font-sanskrit text-saffron-light mb-4">Stay Connected</h3>
            <p className="text-gray-300 mb-4">Subscribe to receive updates about Hindu festivals and events.</p>
            <form className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="bg-deepBlue-light px-4 py-2 rounded-l-md focus:outline-none focus:ring-2 focus:ring-gold-light text-white flex-grow"
              />
              <button
                type="submit"
                className="bg-gold-DEFAULT hover:bg-gold-dark transition-colors px-4 py-2 rounded-r-md font-medium"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-deepBlue-light text-center">
          <p className="text-gray-400">
            &copy; {currentYear} Sanatan Dharma Awareness. Designed & Conceptualized by Utpal.
          </p>
          <p className="text-gray-500 text-sm mt-2">
            "धर्मो रक्षति रक्षितः" (Dharmo Rakshati Rakshitah) — Dharma protects those who protect it.
          </p>
        </div>
      </div>
    </footer>
  );
} 