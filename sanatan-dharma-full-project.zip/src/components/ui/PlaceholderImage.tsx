'use client';

import React from 'react';
import Image from 'next/image';
import { FaOm } from 'react-icons/fa';

interface PlaceholderImageProps {
  src: string;
  alt: string;
  fill?: boolean;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
}

export default function PlaceholderImage({
  src,
  alt,
  fill = false,
  width,
  height,
  className = '',
  priority = false
}: PlaceholderImageProps) {
  const [isError, setIsError] = React.useState(false);

  const handleError = () => {
    setIsError(true);
  };

  if (isError) {
    return (
      <div 
        className={`bg-gradient-to-br from-deepBlue-DEFAULT to-deepBlue-dark flex items-center justify-center ${className}`}
        style={fill ? { position: 'absolute', inset: 0 } : { width, height }}
      >
        <div className="flex flex-col items-center justify-center text-gold-light">
          <FaOm className="text-5xl mb-2" />
          <span className="text-xs text-center text-gray-300">{alt}</span>
        </div>
      </div>
    );
  }

  if (fill) {
    return (
      <Image
        src={src}
        alt={alt}
        fill
        className={className}
        onError={handleError}
        priority={priority}
      />
    );
  }

  return (
    <Image
      src={src}
      alt={alt}
      width={width || 300}
      height={height || 300}
      className={className}
      onError={handleError}
      priority={priority}
    />
  );
} 