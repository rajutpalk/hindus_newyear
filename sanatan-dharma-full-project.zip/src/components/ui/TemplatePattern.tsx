'use client';

import React from 'react';
import { motion } from 'framer-motion';

interface TemplatePatternProps {
  className?: string;
  opacity?: number;
}

export default function TemplatePattern({ className = '', opacity = 0.05 }: TemplatePatternProps) {
  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`} style={{ opacity }}>
      <motion.div 
        className="w-full h-full"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5 }}
      >
        {/* SVG Temple Pattern */}
        <svg width="100%" height="100%" viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="templePattern" patternUnits="userSpaceOnUse" width="200" height="200">
              <g fill="currentColor" stroke="none">
                {/* Om Symbol */}
                <path d="M100,10 C128,10 150,32 150,60 C150,88 128,110 100,110 C72,110 50,88 50,60 C50,32 72,10 100,10 Z M100,30 C83,30 70,43 70,60 C70,77 83,90 100,90 C117,90 130,77 130,60 C130,43 117,30 100,30 Z M150,70 C150,70 130,120 80,120 C30,120 10,70 10,70" 
                  strokeWidth="5" stroke="currentColor" fill="none"/>
                
                {/* Swastika (Hindu Symbol of Good Fortune) */}
                <path d="M30,30 L50,30 L50,10 L70,10 L70,50 L30,50 L30,70 L10,70 L10,50 L50,50" 
                  strokeWidth="3" stroke="currentColor" fill="none"/>
                
                {/* Kalash (Sacred Pot) */}
                <path d="M160,50 C160,40 170,40 175,40 C180,40 190,40 190,50 C190,60 180,80 175,100 C170,80 160,60 160,50 Z M160,45 L190,45 M175,100 L175,110 M165,110 L185,110" 
                  strokeWidth="3" stroke="currentColor" fill="none"/>
                
                {/* Temple Dome */}
                <path d="M100,150 C100,130 130,130 150,150 C170,130 200,130 200,150 L200,180 L100,180 Z" 
                  strokeWidth="3" stroke="currentColor" fill="none"/>
                <path d="M150,150 L150,130" strokeWidth="3" stroke="currentColor" fill="none"/>
                
                {/* Simple Diya (Lamp) */}
                <path d="M20,160 C20,150 40,150 40,160 L20,160 Z M30,160 L30,170 M25,170 L35,170" 
                  strokeWidth="2" stroke="currentColor" fill="none"/>
                
                {/* Lotus Flower */}
                <path d="M80,80 C85,70 95,70 100,80 C105,70 115,70 120,80 C125,70 135,70 140,80 C135,90 125,90 120,80 C115,90 105,90 100,80 C95,90 85,90 80,80 Z" 
                  strokeWidth="2" stroke="currentColor" fill="none"/>
              </g>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#templePattern)" />
        </svg>
      </motion.div>
    </div>
  );
} 